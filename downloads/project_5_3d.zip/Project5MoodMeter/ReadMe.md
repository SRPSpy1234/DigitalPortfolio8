Here are the designs for the Mood Meter Project. Feel free to use them as a reference or modify them but please don't directly copy. If you want more info about this project visit [this](https://digital-portfolio-8-spencer-paley-sitko-15553129.codehs.me/projects/p5.html) website. All designs here are made by Spencer Paley-Sitko. Thanks!

