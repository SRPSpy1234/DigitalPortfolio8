Here are the designs for the Mood Meter Project. Feel free to use them as a reference or modify them but please don't directly copy. If you want more info about this project visit [this](https://spencerpaleysitko.com/projects/p5.html) website. All designs here are made by Spencer Paley-Sitko. Thanks!

Components used in this build:
    1. Hiwonder 25k 270 degree servo motor
    2. 10k ohm potentiometer
    3. Arduino Uno R4 Wifi
    4. Medium Breadboard

3D Printer Filaments Used:
    1. Elegoo PLA+ White
    2. Elegoo PLA+ Black
    3. eSun PLA Red

